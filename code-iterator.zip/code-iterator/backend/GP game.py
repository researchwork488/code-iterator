import pygame

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("GP - Action Movement Demo")
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 150, 255)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)

# GP Character setup
gp = pygame.Rect(375, 500, 50, 50)
gp_color = BLUE
velocity = 5
is_jumping = False
jump_count = 10
state = "idle"

# Game loop
running = True
while running:
    screen.fill(WHITE)
    pygame.draw.rect(screen, gp_color, gp)
    font = pygame.font.SysFont(None, 28)
    state_text = font.render(f"State: {state}", True, (0, 0, 0))
    screen.blit(state_text, (10, 10))

    keys = pygame.key.get_pressed()

    # Movement
    state = "idle"
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        gp.x -= velocity
        state = "moving left"
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        gp.x += velocity
        state = "moving right"
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        gp.y -= velocity
        state = "moving up"
    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        gp.y += velocity
        state = "moving down"

    # Actions
    if keys[pygame.K_SPACE] and not is_jumping:
        is_jumping = True
        state = "jumping"
    if keys[pygame.K_LSHIFT]:
        state = "sliding"
        gp_color = YELLOW
    elif keys[pygame.K_LCTRL]:
        state = "crouching"
        gp_color = GREEN
    elif keys[pygame.K_z]:
        state = "prone"
        gp_color = RED
    else:
        gp_color = BLUE

    if is_jumping:
        if jump_count >= -10:
            gp.y -= (jump_count * abs(jump_count)) * 0.3
            jump_count -= 1
        else:
            is_jumping = False
            jump_count = 10

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.update()
    clock.tick(60)

pygame.quit()
