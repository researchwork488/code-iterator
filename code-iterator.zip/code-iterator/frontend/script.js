async function generateSuggestion() {
    const code = document.getElementById('codeInput').value;
    const prompt = document.getElementById('promptInput').value;

    if (!code.trim() || !prompt.trim()) {
        alert('Please fill in both the code and the prompt!');
        return;
    }

    try {
        const response = await fetch('http://127.0.0.1:5000/process-code', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ code, prompt })
        });

        const data = await response.json();
        document.getElementById('suggestedCode').value = data.improved_code;
        document.getElementById('explanation').innerText = "Explanation: " + data.explanation;

    } catch (error) {
        console.error('Error:', error);
        alert('Something went wrong. Please check the server or code.');
    }
}

function integrateCode() {
    const finalCode = document.getElementById('suggestedCode').value;
    if (!finalCode.trim()) {
        alert('No suggestion to integrate!');
        return;
    }
    document.getElementById('finalCode').value = finalCode;
}
