from flask import Flask, request, jsonify
from flask_cors import CORS
from optimizer import optimize_code

# Flask app setup
app = Flask(__name__)
CORS(app)

@app.route('/process-code', methods=['POST'])
def process_code():
    data = request.get_json()
    code = data.get("code", "")
    prompt = data.get("prompt", "")

    optimized_code, explanation = optimize_code(code, prompt)

    return jsonify({
        "improved_code": optimized_code,
        "explanation": explanation
    })

if __name__ == "__main__":
    app.run(debug=True)
