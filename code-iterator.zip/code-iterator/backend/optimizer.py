import re

# detect language

def detect_language(code):
    if "KeyCode." in code or "Vector3" in code or "transform.position" in code:
        return "csharp"
    elif "pygame." in code and "pygame.K_" in code:
        return "pygame"
    else:
        return "unknown"


def optimize_code(code, prompt=""):
    lang = detect_language(code)
    if lang == "csharp":
        return apply_user_intent_csharp(code, prompt)
    elif lang == "pygame":
        return apply_user_intent_pygame(code, prompt)
    else:
        return code, "Language not supported or prompt did not match."


# prompt intent for C#

def apply_user_intent_csharp(code: str, prompt: str):
    explanation = []
    updated_code = code
    prompt = prompt.lower()

    direction_map = {
        "left": "KeyCode.A",
        "right": "KeyCode.D",
        "forward": "KeyCode.W",
        "up": "KeyCode.W",
        "backward": "KeyCode.S",
        "down": "KeyCode.S",
        "jump": "KeyCode.Space",
        "crouch": "KeyCode.LeftControl",
        "dash": "KeyCode.LeftShift"
    }

    for word, key in direction_map.items():
        if any(p in prompt for p in [f"remove {word}", f"disable {word}", f"no {word}"]):
            pattern = rf'\s*if\s*\(Input\.GetKey(Down)?\({key}\)\)\s*{{[^}}]*}}'
            updated_code = re.sub(pattern, '', updated_code)
            explanation.append(f"Removed {word} movement bound to {key}.")

    if "invert controls" in prompt:
        updated_code = updated_code.replace("KeyCode.W", "KeyCode.TEMP1")
        updated_code = updated_code.replace("KeyCode.S", "KeyCode.W")
        updated_code = updated_code.replace("KeyCode.TEMP1", "KeyCode.S")
        updated_code = updated_code.replace("KeyCode.A", "KeyCode.TEMP2")
        updated_code = updated_code.replace("KeyCode.D", "KeyCode.A")
        updated_code = updated_code.replace("KeyCode.TEMP2", "KeyCode.D")
        explanation.append("Inverted movement controls (W/S, A/D).")

    if "arrow keys" in prompt:
        updated_code = updated_code.replace("KeyCode.W", "KeyCode.UpArrow")
        updated_code = updated_code.replace("KeyCode.S", "KeyCode.DownArrow")
        updated_code = updated_code.replace("KeyCode.A", "KeyCode.LeftArrow")
        updated_code = updated_code.replace("KeyCode.D", "KeyCode.RightArrow")
        explanation.append("Replaced WASD with arrow keys.")

    if "log position" in prompt:
        log_code = 'Debug.Log(transform.position);'
        if log_code not in updated_code:
            updated_code = re.sub(r'(void Update\(\)\s*{)', r'\1\n    ' + log_code, updated_code)
            explanation.append("Added Debug.Log to log character position.")

    if "face direction" in prompt or "character faces" in prompt:
        if "transform.forward" not in updated_code:
            face_code = '\n    if (move != Vector3.zero)\n    {\n        transform.forward = move.normalized;\n    }'
            updated_code = re.sub(r'(void Update\(\)\s*{)', r'\1' + face_code, updated_code)
            explanation.append("Character now faces movement direction.")

    if "add jump" in prompt:
        if "KeyCode.Space" not in updated_code:
            jump_code = '\n    if (Input.GetKeyDown(KeyCode.Space))\n    {\n        // Jump logic here\n    }'
            updated_code = re.sub(r'(void Update\(\)\s*{)', r'\1' + jump_code, updated_code)
            explanation.append("Added jump logic with Space key.")

    if "dash" in prompt:
        dash_code = '\n    if (Input.GetKeyDown(KeyCode.LeftShift))\n    {\n        // Dash logic here\n    }'
        updated_code = re.sub(r'(void Update\(\)\s*{)', r'\1' + dash_code, updated_code)
        explanation.append("Added dash logic with LeftShift.")

    if "glide" in prompt or "friction" in prompt:
        friction_code = '\n    move *= 0.95f; // simulate glide/friction\n'
        updated_code = re.sub(r'(transform\.position\s*\+=\s*move\s*\*.*?;)', r'\1' + friction_code, updated_code)
        explanation.append("Applied glide/friction damping.")

    final_expl = " ".join(explanation) if explanation else "No prompt-specific transformation applied."
    return updated_code, final_expl


# prompt intent by python

def apply_user_intent_pygame(code: str, prompt: str):
    explanation = []
    updated_code = code
    prompt = prompt.lower()

    direction_map = {
        "left": "pygame.K_a",
        "right": "pygame.K_d",
        "forward": "pygame.K_w",
        "up": "pygame.K_w",
        "backward": "pygame.K_s",
        "down": "pygame.K_s",
        "jump": "pygame.K_SPACE"
    }

    for word, key in direction_map.items():
        if any(p in prompt for p in [f"remove {word}", f"disable {word}", f"no {word}"]):
            pattern = rf'\s*if\s*keys\[{key}\]:\s*\n(\s+.+\n)*'
            updated_code = re.sub(pattern, '', updated_code)
            explanation.append(f"Removed {word} movement bound to {key}.")

    if "invert controls" in prompt:
        updated_code = updated_code.replace("pygame.K_w", "TEMP_W")
        updated_code = updated_code.replace("pygame.K_s", "pygame.K_w")
        updated_code = updated_code.replace("TEMP_W", "pygame.K_s")
        updated_code = updated_code.replace("pygame.K_a", "TEMP_A")
        updated_code = updated_code.replace("pygame.K_d", "pygame.K_a")
        updated_code = updated_code.replace("TEMP_A", "pygame.K_d")
        explanation.append("Inverted controls (W/S, A/D).")

    if "log position" in prompt and "print((x, y))" not in updated_code:
        updated_code = re.sub(r'(pygame\.display\.update\(\))', r'print((x, y))\n    \1', updated_code)
        explanation.append("Logged player position every frame.")

    if "double speed" in prompt or "twice as fast" in prompt:
        updated_code = re.sub(r'(speed\s*=\s*)(\d+)', lambda m: f"{m[1]}{int(m[2]) * 2}", updated_code)
        explanation.append("Doubled player speed.")

    if "half speed" in prompt or "slower" in prompt:
        updated_code = re.sub(r'(speed\s*=\s*)(\d+)', lambda m: f"{m[1]}{max(1, int(int(m[2]) / 2))}", updated_code)
        explanation.append("Reduced player speed.")

    final_expl = " ".join(explanation) if explanation else "No prompt-specific transformation applied."
    return updated_code, final_expl
